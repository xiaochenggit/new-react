# redux-todoList

使用redux重新改写todoList，统一管理state状态

### 搭建工具

使用react官方脚手架create-react-app

### 更新记录 

3/23 添加注释，ES6语法，简单样式美化

### 总结

学习了redux的基本用法，理解了其数据流的运行过程和原理，后续将继续改进，配合打包工具webpack构建项目。
