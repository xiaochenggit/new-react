# react-simple-o2o-demo

fetch 获取/提交数据，以及开发环境下的数据 Mock，文档参见[这里](./docs/README.md)