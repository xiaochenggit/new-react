import React from 'react'

class NotFound extends React.Component {
    render() {
        return (
            <p>404 NotFound</p>
        )
    }
}

export default NotFound