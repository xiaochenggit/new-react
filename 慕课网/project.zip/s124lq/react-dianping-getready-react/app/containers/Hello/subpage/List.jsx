import React from 'react'

class List extends React.Component {
    render() {
        return (
             <p>列表</p>
        )
    }
}

export default List