module.exports = {
    hasMore: true,
    data: [
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145742279-606202974.jpg',
            title: '河束人家',
            subTitle: '南锣鼓巷店',
            price: '150',
            distance: '120m',
            mumber: '389'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145750123-1745839503.jpg',
            title: '漫漫火锅',
            subTitle: '[王府井]自助火锅',
            price: '113',
            distance: '140m',
            mumber: '689'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145755545-1770557408.jpg',
            title: '北方涮肉',
            subTitle: '什刹海店',
            price: '92',
            distance: '160',
            mumber: '106'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145800732-576947550.jpg',
            title: '姓高火锅',
            subTitle: '知春里店',
            price: '90',
            distance: '160',
            mumber: '58'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145806201-1193851669.jpg',
            title: '八重牛府',
            subTitle: '最好吃的牛丸',
            price: '85',
            distance: '160',
            mumber: '1426'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022150855185-1659375763.jpg',
            title: '蜀乡涮锅',
            subTitle: '[王府井]自助火锅',
            price: '113',
            distance: '140m',
            mumber: '689'
        },
        {
            img: 'http://images2015.cnblogs.com/blog/138012/201610/138012-20161022145800732-576947550.jpg',
            title: '满楼福火锅',
            subTitle: '知春路店',
            price: '90',
            distance: '160',
            mumber: '58'
        }
    ]
}