# react-simple-o2o-demo

React + React-router + Redux 的前端代码框架，文档参见[这里](./docs/README.md)