# react-simple-o2o-demo

React 性能优化，详情参考[这里](./docs/README.md)