---
id: immutable
title: ImmutableJS – Immutable Data
layout: docs
category: Resources
permalink: http://facebook.github.io/immutable-js/
next: jest
---
