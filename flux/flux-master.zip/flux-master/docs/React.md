---
id: react
title: React – UI Library
layout: docs
category: Resources
permalink: http://facebook.github.io/react/
next: immutable
---
