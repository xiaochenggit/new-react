---
id: jest-ko-KR
title: Jest – 단위 테스팅
layout: docs
category: Resources
permalink: http://facebook.github.io/jest/
lang: ko-KR
---
